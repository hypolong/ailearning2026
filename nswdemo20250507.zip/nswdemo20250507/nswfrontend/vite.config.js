import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    host: "10.16.52.148",
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://10.16.52.148:8000',
        changeOrigin: true
      }
    }
  }
})