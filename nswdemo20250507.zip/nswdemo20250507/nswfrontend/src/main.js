import { createApp } from 'vue'
// import './style.css'
import 'element-plus/dist/index.css'
import App from './App.vue'

import router from "./router/index.js"

createApp(App).use(router).mount("#app")
// createApp(App).mount('#app')
