<template>
  <div class="container">
    
    <Login v-if="!user" @login="onLogin"/>
    
    <!-- 登录后才显示路由页面 -->
    <div v-else>
      <router-view :user="user" @logout="user=null"/>
    </div>
    <!-- <Report :user="user" @logout="user=null"/> -->
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Login from './components/Login.vue'
import Report from './components/Report.vue'

const user = ref(null)

const onLogin = (u) => {
  user.value = u
}
</script>

<style>
.container {
  background: #1e1e1e;
  color: #fff;
  height: 97vh;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>