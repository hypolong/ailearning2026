<template>
  <div class="dashboard">
    <div class="header">
      <img :src="graphicon" style="height: 30px; width: 30px;;" alt="production info">
      <h2 style="padding-left: 1%; color: aliceblue;"> DashBoard for production monitoring</h2>
    </div>
    <!-- 第一行 -->
    <div class="row">
      <div ref="jobChart" class="chart"></div>
      <div ref="productionChart" class="chart"></div>
    </div>

    <!-- 第二行 -->
    <div class="row">
      <div ref="cumulativeChart" class="chart"></div>
      <div ref="statsChart" class="chart"></div>
    </div>

    <div style="margin-top:10px; height: 50px; display: flex; justify-content: flex-end; align-items: center;">
      <button @click="goBack" style="height: 30px;">Return to Main Page</button>
    </div>

  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, nextTick } from "vue"
import * as echarts from "echarts"
import axios from "axios"
import { useRoute, useRouter } from "vue-router"
import graphicon from '../assets/dashboard.png'

const route = useRoute()
const router = useRouter()

const workcenter = route.query.workcenter
const productcode = route.query.productcode

const goBack = () => {
  router.push("/")
}

// 图表 DOM
const jobChart = ref(null)
const productionChart = ref(null)
const cumulativeChart = ref(null)
const statsChart = ref(null)

// 实例
let jobChartInstance = null
let productionChartInstance = null
let cumulativeChartInstance = null
let statsChartInstance = null

// ======================
// 获取数据
// ======================
const fetchData = async () => {
  const jobRes = await axios.get('http://10.16.52.148:8000/api/workcenter_jobs', {
    params: { workcenter_key: "all" }
  })

  const productionRes = await axios.get('http://10.16.52.148:8000/api/production_records', {
    params: { production_key: "all" }
  })

  updateJobChart(jobRes.data)
  updateProductionChart(productionRes.data)
  updateCumulativeChart(productionRes.data)
  updateStatsChart(productionRes.data)
}

// ======================
// 图1：工位趋势
// ======================
const updateJobChart = (data) => {
  jobChartInstance.setOption({
    title: { text: 'Production Plan' },
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: data.categories },
    yAxis: { type: 'value' },
    series: data.series.map(s => ({
      name: s.name,
      type: 'line',
      data: s.data,
      smooth: true
    }))
  })
}

// ======================
// 图2：产量（柱 + 折线）
// ======================
const updateProductionChart = (data) => {
  productionChartInstance.setOption({
    title: { text: 'Production Recording' },
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: data.categories },
    yAxis: { type: 'value' },
    series: [
      { type: 'bar', data: data.series[0].data },
      { type: 'line', data: data.series[0].data, smooth: true }
    ]
  })
}

// ======================
// 图3：累计产量
// ======================
const updateCumulativeChart = (data) => {
  let cumulative = []
  let sum = 0

  data.series[0].data.forEach(v => {
    sum += v
    cumulative.push(sum)
  })

  cumulativeChartInstance.setOption({
    title: { text: 'Cumulative Production' },
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: data.categories },
    yAxis: { type: 'value' },
    series: [
      {
        type: 'line',
        data: cumulative,
        smooth: true,
        areaStyle: {}
      }
    ]
  })
}

// ======================
// 图4：统计分析
// ======================
const updateStatsChart = (data) => {
  const arr = data.series[0].data

  const max = Math.max(...arr)
  const min = Math.min(...arr)
  const avg = (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2)

  statsChartInstance.setOption({
    title: { text: 'Statistics' },
    tooltip: {},
    xAxis: {
      type: 'category',
      data: ['Max', 'Min', 'Avg']
    },
    yAxis: { type: 'value' },
    series: [
      {
        type: 'bar',
        data: [max, min, avg]
      }
    ]
  })
}

// ======================
// 生命周期
// ======================
onMounted(async () => {
  await nextTick()

  jobChartInstance = echarts.init(jobChart.value)
  productionChartInstance = echarts.init(productionChart.value)
  cumulativeChartInstance = echarts.init(cumulativeChart.value)
  statsChartInstance = echarts.init(statsChart.value)

  fetchData()

  setInterval(fetchData, 5000)

  window.addEventListener('resize', () => {
    jobChartInstance.resize()
    productionChartInstance.resize()
    cumulativeChartInstance.resize()
    statsChartInstance.resize()
  })
})

onBeforeUnmount(() => {
  jobChartInstance.dispose()
  productionChartInstance.dispose()
  cumulativeChartInstance.dispose()
  statsChartInstance.dispose()
})

let resizeHandler = null

onMounted(async () => {
  await nextTick()

  jobChartInstance = echarts.init(jobChart.value)
  productionChartInstance = echarts.init(productionChart.value)
  cumulativeChartInstance = echarts.init(cumulativeChart.value)
  statsChartInstance = echarts.init(statsChart.value)

  fetchData()

  resizeHandler = () => {
    jobChartInstance?.resize()
    productionChartInstance?.resize()
    cumulativeChartInstance?.resize()
    statsChartInstance?.resize()
  }

  window.addEventListener('resize', resizeHandler)

  setTimeout(resizeHandler, 100)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', resizeHandler)
})
</script>

<style scoped>
.dashboard {
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 10px;
  box-sizing: border-box;
  background: #3d3c3c;
}

.header {
  flex: 0 0 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: aliceblue;
  width: 100%;
}

.row {
  flex: 1;
  display: flex;
  gap: 10px;
}

.chart {
  flex: 1;
  height: 100%;
  background: #b4b0b0;
  border-radius: 10px;
}
</style>