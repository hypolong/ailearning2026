<template>
  <div v-if="visible" class="msg">{{ text }}</div>
</template>

<script setup>
import { ref } from 'vue'

const visible = ref(false)
const text = ref('')

const show = (msg) => {
  text.value = msg
  visible.value = true

  setTimeout(() => {
    visible.value = false
  }, 2000)
}

defineExpose({ show })
</script>

<style>
.msg {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: #409eff;
  color: white;
  padding: 10px 20px;
  border-radius: 6px;
}
</style>