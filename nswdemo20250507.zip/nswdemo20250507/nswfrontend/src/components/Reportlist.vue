<script setup>
import { ref, onMounted,computed  } from "vue"
import axios from "axios"
import { useRouter } from "vue-router"

const router = useRouter()

const goBack = () => {
  router.push("/") 
}

const list = ref([])
const filter = ref("all") // all / sent / unsent

const fetchData = async () => {
  try {
    let url = "http://10.16.52.148:8000/api/workinfolist"

    if (filter.value === "sent") {
      url += "?is_sent=1"
    } else if (filter.value === "unsent") {
      url += "?is_sent=0"
    }

    const res = await axios.get(url)
    list.value = res.data

    currentPage.value = 1
  } catch (err) {
    console.error(err)
  }
}

onMounted(() => {
  fetchData()
})

const currentPage = ref(1)
const pageSize = ref(10)
const paginatedList = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  return list.value.slice(start, end)
})

const totalPages = computed(() => {
  return Math.ceil(list.value.length / pageSize.value)
})

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--
  }
}

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
  }
}

</script>

<template>
  <div style="height: 90vh;">
    <h2 style="color: aliceblue;" >Production Recod List</h2>

    <!-- 筛选 -->
    <div style="margin-bottom: 10px;">
      <label style="padding-right: 1%;">Filter: </label>
      <select style="width: 100px; font-size: medium;" v-model="filter" @change="fetchData">
        <option value="all">all</option>
        <option value="sent">sent</option>
        <option value="unsent">unsent</option>
      </select>
     
      <label style="padding-left: 50%;"></label>
      <!-- 返回按钮 -->
      <button style="align-content: end;" @click="goBack">
        Return to Main Page 
      </button>
    </div>
    
    <!-- 表格 -->
    <table style="font-size: 14px;" border="1" cellspacing="0" cellpadding="5">
      <thead>
        <tr>
          <th>ID</th>
          <th>Workcenter</th>
          <th>Job</th>
          <th>Operator</th>
          <th>Part</th>
          <th>Quantity</th>
          <th>Device-PLC</th>
          <th>Auto-Record</th>
          <th>Created Time</th>
          <th>Sent to Plex</th>
        </tr>
      </thead>

      <tbody>
        <tr v-for="item in paginatedList" :key="item.id">
          <td>{{ item.id }}</td>
          <td>{{ item.workcenter_id }}</td>
          <td>{{ item.job_id }}</td>
          <td>{{ item.user_id }}</td>
          <td>{{ item.product_code }}</td>
          <td>{{ item.quantity }}</td>
          <td>{{ item.machine_id }}</td>
          <td>
            <span :style="{color: item.report_auto ? 'green' : 'yellow'}">
            {{ item.report_auto ? "自動" : "手動" }}
            </span>
          </td>
          <td>{{ item.timestamp }}</td>

          <!-- 状态显示 -->
          <td>
            <span :style="{color: item.is_sent ? 'green' : 'yellow'}">
              {{ item.is_sent ? "報告済" : "未報告" }}
            </span>
          </td>
        </tr>
      </tbody>
    </table>
    <div style="margin-top: 10px; text-align: center;">
      <button @click="prevPage" :disabled="currentPage === 1">
        previous page
      </button>

      <span style="margin: 0 10px;">
        No. {{ currentPage }} / {{ totalPages }} Page
      </span>

      <button @click="nextPage" :disabled="currentPage === totalPages">
        Next Page
      </button>
    </div>
  </div>
</template>