<template>
  <div class="page">
    <!-- workcenter status -->
    <div class="container">
       <!-- 顶部：标题 -->
      <div class="header">
        <img :src="statuspng" style="height: 30px; width: 30px;;" alt="workcenter info">
        <h2 style="padding-left: 1%; color: aliceblue;"> Workcenter Status</h2>
      </div>
      
      <!-- 中间：表单 -->
      <div class="body">
         
        <div class="status-item">
          <label style="padding-right: 2%; text-align: right;">WorkCenter:</label>
          <label v-if="workinfo"style="padding-left: 1%; text-align: left;">{{workinfo?.workcenter_name}}</label> 
        </div>
        <div class="status-item">
          <label style="padding-right: 2%; text-align: right;">Job:</label>
          <label style="padding-left: 1%; text-align: left;">{{workinfo?.workcenter_job}}</label> 
        </div>
        <div class="status-item">
          <label style="padding-right: 2%; text-align: right;">Operator:</label>
          <label style="padding-left: 1%; text-align: left;">{{workinfo?.operator}}</label> 
        </div>
        <div class="status-item">
          <label style="padding-right: 2%; text-align: right;">Workcenter Status:</label>
          <label style="padding-left: 1%; text-align: left;">{{workinfo?.workcenter_status}}</label> 
        </div>
        <div class="status-item">
          <label style="padding-right: 2%; text-align: right;">Job Quality:</label>
          <label style="padding-left: 1%; text-align: left;">{{workinfo?.job_quantity }}</label> 
        </div>
        <div class="status-item">
          <label style="padding-right: 2%; text-align: right;">Job Procedured:</label>
          <label style="padding-left: 1%; text-align: left;">{{workinfo?.job_procedured}}</label> 
        </div>
        <div class="status-item">
          <label style="padding-right: 2%; text-align: right;">Job Status:</label>
          <label style="padding-left: 1%; text-align: left;">{{workinfo?.job_status}}</label> 
        </div>
      </div> 

      <!-- 底部：按钮 -->
      <div class="footer">
        <button class="btn submit"  @click="showlog">
          <span v-if="loading_log" class="spinner"></span>
          <span v-else>Logs</span>
        </button>
        <label style="width: 20px;"></label>
        <button class="btn submit"   @click="goToList">Reported List</button>
        <label style="width: 20px;"></label>
        <button @click="goToChart" class="btn submit">
        📊 Dashboard
      </button>
      </div>

      <!-- update time info -->
      <div>
        <label>updated by {{ new Date().toLocaleString('en-JP') }} </label>
        <Message ref="msgRef" />
      </div>
    </div>
    <div style="width: 170px;  margin-left: -1%; align-items: center;justify-content: center;">
      <img :src="workerpng" style="padding-left:40%; height: 50px; width: 50px;" alt="workcenter info">
      <button class="changeworkcenter"  @click="showChangeWorkcenter">
        <span  style="font-size: 14px; ">🔗WorkCenter Select🔗</span>
      </button>
      <select v-if="changeWorkcenterFlag" class="custom-select" v-model="filter" @change="changeWorkcenter">
        <option value="pressing_shop">pressing_shop</option>
        <option value="welding_shop">welding_shop</option>
        <option value="painting_shop">painting_shop</option>
      </select>
    </div>
   
    <!-- record production -->
    <div class="container">
      <!-- 顶部：标题 -->
      <div class="header">
        <img :src="graphpng" style="height: 30px; width: 30px;;" alt="workcenter info">
        <h2 style="padding-left: 1%; color: aliceblue;"> Record and Report Production</h2>
      </div>
      <div class="status-item">
          <label style="height: 10vh;"></label>
      </div>
      <!-- 中间：表单 -->
      <div class="body">
        <div class="form-item">
          <label style="padding-right: 2%; text-align: right;">WorkCenter:</label>
          <input :disabled="true" v-model="workcenter_id" @input="validate_Workcenter" placeholder="Workcenter"/>
          <p style="padding-left: 1%; color:#FFFF00">{{ error_workcenter }}</p>
        </div>

        <div class="form-item">
          <label style="padding-right: 2%; text-align: right;">Job:</label>
          <input :disabled="true" v-model="job_id" @input="validate_job" placeholder="Job"/>
          <p style="padding-left: 1%; color:#FFFF00">{{ error_job_id }}</p>
        </div>

        <div class="form-item">
          <label style="padding-right: 2%; text-align: right;">Production:</label>
          <input :disabled="true" v-model="product_code" @input="validate_Production" placeholder="default"/>
          <p style="padding-left: 1%; color:#FFFF00">{{ error_product_code }}</p>
        </div>

        <div class="form-item">
          <label style="padding-right: 2%; text-align: right;">count:</label>
          <input :disabled="isChecked" v-model="quantity" @input="validate_quality" @blur="validate_final"  placeholder="quantity"/>
          <p style="padding-left: 1%; color:#FFFF00">{{ error_quantity }}</p>
        </div>

        <div>
          <!-- checkbox -->
          <label style="padding-left: 20%;">
            <input  type="checkbox"  v-on:click="setrecordmode" v-model="isChecked" />
            Auto Record and Report
          </label>
          <br />
          <label style="padding-left: 20%;">
          <input  type="checkbox" v-on:click="setrecordhistrorian" v-model="isHistorianChecked" />
          Historian Production or not
        </label>
        </div>
        
      </div>

      <!-- 底部：按钮 -->
      <div class="footer">
        <button :disabled="isChecked || loading" class="btn submit"  @click="recordproduction">
          <span v-if="loading" class="spinner"></span>
          <span v-else>Manual Report</span>
        </button>
        <label style="width: 20px;"></label>
        <button class="btn submit" @click="logout">logout</button>
      </div>

      <!-- login user info -->
      <div>
        <label>Welcome {{ user }} </label>
        <Message ref="msgRef" />
      </div>
    </div>
  </div>
</template>

<script setup>
import axios from 'axios'
import { ref, onMounted, onUnmounted} from 'vue'
import Message from './Message.vue'
import graphpng from '../assets/graph.png'
import statuspng from '../assets/status.png'
import workerpng from '../assets/worker.png'

const msgRef = ref(null)
import { ElMessageBox } from 'element-plus'

const props = defineProps({
  user: String
})

const emit = defineEmits(['logout'])

//for workcenter status******************
const isChecked = ref(false)
const isHistorianChecked=ref(false)
const WorkCenter_name=ref('')
WorkCenter_name.value=''

const workinfo = ref(null)
let ws = null

const connect = () => {
  if (ws) {
    ws.close();  //防止重复连接
  }
  
  ws = new WebSocket("ws://10.16.52.148:8000/ws/workinfo")

  ws.onclose = () => {
    console.log("reconnect to backend...")
    setTimeout(connect, 3000)
  }

  ws.onmessage = (event) => {
    workinfo.value = JSON.parse(event.data)

    workcenter_id.value = workinfo.value.workcenter_name
    job_id.value = workinfo.value.workcenter_job
    product_code.value = workinfo.value.product_code
    filter.value = workinfo.value.workcenter_name
  }
}

onMounted(() => {
  connect();
  axios.post("http://10.16.52.148:8000/auto-report/status", {
        "workcenter_key": "pressing_shop"
      }).then(res => {
    isChecked.value = res.data.enabled;
    isHistorianChecked.value = res.data.histrorian;
  });
})

// 页面销毁时关闭连接
onUnmounted(() => {
  if (ws) {
    ws.close()
  }
})

//for record and report production**************************
const workcenter_id = ref('painting01')
const job_id = ref('1')
const product_code = ref('vehile-serial01')
const quantity = ref('1')

const error_workcenter = ref('')
const error_job_id = ref('')
const error_product_code = ref('')
const error_quantity = ref('')

const validate_Workcenter = () => {
  if (!/^[a-zA-Z0-9_-]+$/.test(workcenter_id.value)) {
    error_workcenter.value = 'PLEXでは特別な記号はサポートできせん。'
  } else {
    error_workcenter.value = ''
  }
}

const validate_job = () => {
  if (!/^[1-999999]+$/.test(job_id.value)) {
    error_job_id.value = '1以上の数字が必要'
  } else {
    error_job_id.value = ''
  }
}

const validate_Production = () => {
  if (!/^[a-zA-Z0-9_-]+$/.test(product_code.value)) {
    error_product_code.value = 'PLEXでは特別な記号はサポートできせん。'
  } else {
    error_product_code.value = ''
  }
}

const validate_quality = (e) => {
  const value = e.target.value.trim()

  // 只限制：数字 + 最多5位（输入阶段）
  if (!/^\d{0,5}$/.test(value)) {
    error_quantity.value = '5桁以内の数字'
    return
  }

  // 输入过程中不报“0错误”
  error_quantity.value = ''
}

const validate_final = () => {
  const value = String(quantity.value).trim()

  if (value === '') return

  if (Number(value) === 0) {
    error_quantity.value = '1以上の数字'
  }
}

const loading = ref(false)
const loading_log = ref(false)
const changeWorkcenterFlag  = ref(false)

//用于显示或者隐藏workcenter变更
const filter = ref("pressing_shop") 
const showChangeWorkcenter = async () => {
  changeWorkcenterFlag.value=!changeWorkcenterFlag.value
}

//用于调用后端切换workcenter
const changeWorkcenter = async () => {
  try{
    ws.send(JSON.stringify({
        type: "set_filter",
        value: filter.value
    }))
    ElMessageBox.alert('Workcenter設定しました', 'メッセージ', {
      confirmButtonText: '確定',
      type: 'success'
    })
    changeWorkcenterFlag.value=false
    //get the status of flags again
    axios.post("http://10.16.52.148:8000/auto-report/status", {
          "workcenter_key": filter.value
        }).then(res => {    
      isChecked.value = res.data.enabled;
      isHistorianChecked.value = res.data.histrorian;
    });
    
  }catch{
    ElMessageBox.alert('Workcenter設定失敗しました', 'メッセージ', {
      confirmButtonText: '確定',
      type: 'erro'
    })
  }
}

// 上报生产产量
const recordproduction = async () => {
  if(workinfo.value.workcenter_status!="Production"){
    ElMessageBox.alert('生産状態ではないため報告できない', 'メッセージ', {
          confirmButtonText: '確定',
          type: 'error'
        })
    return
  }
  if(error_workcenter.value==''&& error_job_id.value=='' && error_product_code.value=='' && error_quantity.value==''){
    try{
      loading.value = true 
      const res = await axios.post('http://10.16.52.148:8000/api/recordmanual', {
        user_id: props.user,
        workcenter_id: workcenter_id.value,
        machine_id:"plc01",
        job_id: job_id.value,
        product_code: product_code.value,
        quantity: quantity.value,
        report_auto: 0,
        synced: 1
      })
      if(res.data.msg==1){
        // self customize messagebox
        // msgRef.value.show('実績記録しました')
        ElMessageBox.alert('実績記録しました', 'メッセージ', {
          confirmButtonText: '確定',
          type: 'success'
        })
      }else{
        ElMessageBox.alert('実績記録失敗しました', 'エラー', {
          confirmButtonText: '確定',
          type: 'error'
        })
      }
    }catch(e){
      ElMessageBox.alert('実績記録失敗しました', 'エラー', {
          confirmButtonText: '確定',
          type: 'error'
        })
    }finally {
      loading.value = false
    }
  }else{
    ElMessageBox.alert('エラーが存在しているため、実績報告できません。', 'メッセージ', {
      confirmButtonText: '確定',
      type: 'error'
    })
  }
}

const setrecordmode= async() => {
  if(!isChecked.value){
    const res =  await axios.post('http://10.16.52.148:8000/auto-report/start',{
      "workcenter_key":workcenter_id.value
    })
    if(res.data.msg==1){
      ElMessageBox.alert('自動実績報告スタートしました。', 'メッセージ', {
        confirmButtonText: '確定',
        type: 'success'
      })
    }
  }else{
    const res =  await axios.post('http://10.16.52.148:8000/auto-report/stop',{
      "workcenter_key":workcenter_id.value
    })
    if(res.data.msg==1){
      ElMessageBox.alert('自動実績報告設定停止しました。', 'メッセージ', {
        confirmButtonText: '確定',
        type: 'success'
      })
    }
  }
}

const setrecordhistrorian= async() => {
  if(!isHistorianChecked.value){
    const res =  await axios.post('http://10.16.52.148:8000/report-historian/start',{
      "workcenter_key":workcenter_id.value
    })
    if(res.data.msg==1){
      ElMessageBox.alert('貯まった生産実績もレポートすると設定しました。', 'メッセージ', {
        confirmButtonText: '確定',
        type: 'success'
      })
    }
  }else{
    const res =  await axios.post('http://10.16.52.148:8000/report-historian/stop',{
      "workcenter_key":workcenter_id.value
    })
    if(res.data.msg==1){
      ElMessageBox.alert('貯まった生産実績もレポートないと設定しました。', 'メッセージ', {
        confirmButtonText: '確定',
        type: 'success'
      })
    }
  }
}


const logout = () => {
  ElMessageBox.confirm(
    '本当にログアウトしますか。',
    'メッセージ',
    {
      confirmButtonText: '確定',
      cancelButtonText: 'キャンセル',
      type: 'warning'
    }
  )
    .then(() => {
      emit('logout') 
    })
    .catch(() => {
      // 点击取消
      console.log('取消退出')
    })
}


import { useRouter } from "vue-router"
const router = useRouter()

const goToList = () => {
  router.push("/report-list")
}

const goToChart = () => {
  router.push({
    path: '/dashboard',
    query: {
      workcenter: filter.value,
      productcode: product_code.value
    }
  })
}

const showlog = () => {
  loading_log.value=true
  router.push("/log-list")
  loading_log.value=false
}

</script>

<style scoped>
/* 页面 */
.page {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  width: 100%;
  background: #1e1e1e;
}

/* 主容器 */
.container {
  width: 40vw;
  height: 90vh;              /* 👈 固定高度，方便三段分布 */
  background: #3d3d3d;
  border-radius: 12px;
  color: white;

  display: flex;
  flex-direction: column;   /* 👈 关键：纵向分布 */

  box-shadow: 0 0 20px rgba(0,170,255,0.2);
  overflow: hidden;
}

/* 顶部 */
.header {
  flex: 1;          /* 固定高度 */
  display: flex;
  align-items: center;
  justify-content: center;
  color: aliceblue;
  width: 100%;
}

/* 中间（表单区） */
.body {
  flex: 1;                 /* 占据剩余空间 */
  padding: 10px;

  display: flex;
  flex-direction: column;
  justify-content: center; /* 垂直居中表单 */
  gap: 10px;
}

/* 每一行 */
.form-item {
  display: flex;
  align-items: center;
}

/* label */
.form-item label {
  width: 150px;
}

.status-item {
  display: flex;
  align-items: center;
}

.status-item label {
  width: 250px;
}

/* input */
.form-item input {
  flex: 1;
  width: 240px;
  padding: 10px;
  border-radius: 6px;
  border: none;
  background: #444;
  color: white;
}

.form-item input:disabled {
  background-color: #3a3a3a;
  color: #888;
  border: 1px solid #666;
  cursor: not-allowed;
  opacity: 1; /* 避免太淡 */
}

/* 底部按钮区 */
.footer {
  flex: 0 0 100px;
  display: flex;
  justify-content: space-around;
  align-items: center;
  border-top: 1px solid #444;
}

/* 按钮 */
.btn {
  width: 150px;
  padding: 15px;
  font-size: 16px;
  border: none;
  border-radius: 8px;
  color: white;
  cursor: pointer;

  /* 3D效果 */
  box-shadow: 0 4px 0 rgba(0,0,0,0.4);
  transition: all 0.2s;
}

.btn:disabled {
  display: flex;
  /* height: 40px; */
  text-align: center;
  padding-top: 2px; 
  width: 150px;
  padding: 15px;
  font-size: 16px;
  border: none;
  border-radius: 8px;
  color: rgb(96, 95, 95);
  cursor: not-allowed;

  /* 3D效果 */
  box-shadow: 0 4px 0 rgba(0,0,0,0.4);
  transition: all 0.2s;
}

.btn:active {
  transform: translateY(3px);
  box-shadow: 0 1px 0 rgba(0,0,0,0.4);
}

/* 报告 */
.submit {
  background: linear-gradient(180deg, #00aaff, #0077cc);
}

/* 切换workcenter */
.changeworkcenter {
  width: 150px;
  padding: 15px;
  font-size: 16px;
  border: none;
  border-radius: 8px;
  color: white;
  cursor: pointer;

  /* 3D效果 */
  box-shadow: 0 4px 0 rgba(0,0,0,0.4);
  transition: all 0.2s;

  /* top: 0; */
  position: fixed; 
  display: flex;
  width: 190px;
  height: 40px;
  text-align: center;
  padding-top: 8px; 
  background: linear-gradient(180deg, #0e0e0e, #121111);
}

.changeworkcenter:disabled {
  display: flex;
  height: 40px;
  text-align: center;
  width: 190px;
  font-size: 16px;
  border: none;
  border-radius: 8px;
  color: rgb(96, 95, 95);
  cursor: not-allowed;

  /* 3D效果 */
  box-shadow: 0 4px 0 rgba(0,0,0,0.4);
  transition: all 0.2s;
}
/* 退出 */
.logout {
  background: linear-gradient(180deg, #ff5f5f, #cc0000);
}

.spinner {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #fff;
  border-top: 2px solid transparent;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.custom-select {
  width: 190px;
  padding: 8px 12px;
  margin-top: 25%;
  position:relative;
  font-size: 14px;
  border-radius: 8px;
  border: 1px solid #dcdfe6;
  background-color: #fff;
  color: #333;
  outline: none;
  cursor: pointer;
  transition: all 0.25s ease;

  /* 去掉默认样式 */
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;

  /* 自定义箭头 */
  background-image: url("data:image/svg+xml;utf8,<svg fill='%23999' height='20' viewBox='0 0 20 20' width='20' xmlns='http://www.w3.org/2000/svg'><path d='M5.5 7l4.5 5 4.5-5z'/></svg>");
  background-repeat: no-repeat;
  background-position: right 10px center;
  background-size: 16px;
}

.custom-select:hover {
  border-color: #409eff;
}

.custom-select:focus {
  border-color: #409eff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}
</style>