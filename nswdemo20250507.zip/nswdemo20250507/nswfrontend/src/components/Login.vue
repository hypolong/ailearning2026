<template>
  <div class="login-page" :style="{ backgroundImage: `url(${bg})` }">
      <div class="login-box">
        <h2 class="logo">Plex-MESシステム</h2>
        <!-- <h3>NSW</h3> -->

        <input v-model="username" placeholder="ユーザー名" />
        <input v-model="password" type="password" placeholder="パスワード" />

        <button @click="login">ログイン</button>
        <label style="padding-left: 10%;"> </label>
        <button @click="register">登 録</button>
      </div>
    </div>
</template>

<script setup>
import axios from 'axios'
import { ref } from 'vue'
import bg from '../assets/bg.jpg'

const emit = defineEmits(['login'])

const username = ref('')
const password = ref('')

import { ElMessageBox } from 'element-plus'
const register = async () => {
    ElMessageBox.alert('システム管理者にお願いしてください', 'メッセージ', {
      confirmButtonText: '確定',
      type: 'success'
    })
}

const login = async () => {
  try {
    const res = await axios.post('http://10.16.52.148:8000/api/login', null, {
      params: {
        username: username.value,
        password: password.value
      }
    })
    emit('login', username.value)
  } catch (e) {
    ElMessageBox.alert('ログインできませんでした。', 'メッセージ', {
      confirmButtonText: '確定',
      type: 'erro'
    })
  }
}
</script>

<style scoped>

.login-page {
  position: relative;
  height: 100vh;
  width: 100vw;

  display: flex;
  align-items: center;
  justify-content: flex-start;  /* ⬅️ 靠左 */
  padding-left: 20%;            /* ⬅️ 控制偏移 */
  
  background-size: cover;
  background-position: center;
}

/* 登录框 */
.login-box {
  position: relative;
  z-index: 2;
  width: 300px;
  padding: 40px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(10px);
  box-shadow: 0 0 30px rgba(0, 170, 255, 0.3);
  text-align: center;
  color: #fff;
}

/* 标题 */
.login-box h2 {
  margin-bottom: 20px;
  letter-spacing: 2px;
}

/* 输入框 */
.login-box input {
  width: 200px;
  padding: 12px;
  margin: 10px 0;

  border: none;
  border-radius: 6px;

  background: rgba(255, 255, 255, 0.1);
  color: white;
}

.login-box input::placeholder {
  color: #ccc;
}

/* 按钮 */
.login-box button {
  width: 100px;
  padding: 12px;
  margin-top: 15px;
  align-items: start;
  border: none;
  border-radius: 6px;
  background: linear-gradient(90deg, #00aaff, #0077ff);
  color: white;

  cursor: pointer;
  transition: 0.3s;
}

.login-box button:hover {
  box-shadow: 0 0 10px #00aaff;
  transform: translateY(-1px);
}
</style>