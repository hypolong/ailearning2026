<script setup>
import { ref, onMounted, computed } from "vue"
import axios from "axios"

// 数据
const logs = ref([])

// 分页
const currentPage = ref(1)
const pageSize = ref(4)

// 获取数据
const fetchLogs = async () => {
  try {
    const res = await axios.get("http://10.16.52.148:8000/api/logs")
    console.log(res.data)
    logs.value = res.data.data
    total.value = res.data.total 

    currentPage.value = 1 // 重置页码
  } catch (err) {
    console.error(err)
  }
}

onMounted(() => {
  fetchLogs()
})

// 当前页数据
const paginatedLogs = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  return logs.value.slice(start, start + pageSize.value)
})

// 总页数
const totalPages = computed(() => {
  return Math.ceil(logs.value.length / pageSize.value)
})

// 翻页
const prevPage = () => {
  if (currentPage.value > 1) currentPage.value--
}

const nextPage = () => {
  if (currentPage.value < totalPages.value) currentPage.value++
}

import { useRouter } from "vue-router"

const router = useRouter()

const goBack = () => {
  router.push("/")  // 返回 report.vue
}

</script>

<template>
  <div class="container">

    <!-- 顶部 -->
    <div class="header">
      <h2 style="color: aliceblue;">Log List</h2>
    </div>

    <!-- 中间 -->
    <div class="body">

      <!-- 控制栏 -->
      <div class="toolbar">
        <label>Page Logs Count</label>
        <select v-model="pageSize" style="height: 25px; width: 60px;">
          <option :value="2">2</option>
          <option :value="4">4</option>
          <option :value="8">8</option>
        </select>
        <label style="padding-left: 1%;"></label>
       
      </div>

      <!-- 表格（可滚动） -->
      <div class="table-wrapper">
        <table style="font-size: 14px;">
          <thead>
            <tr>
              <th>ID</th>
              <th>Type</th>
              <th>Message</th>
              <th>Created At</th>
            </tr>
          </thead>

          <tbody>
            <tr v-for="log in paginatedLogs" :key="log.id">
              <td>{{ log.id }}</td>
              <td>
                <span :class="'type-' + log.type">
                  {{ log.type }}
                </span>
              </td>
              <td>{{ log.message }}</td>
              <td>{{ log.created_at }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- 底部 -->
    <div class="footer">
      <button @click="prevPage" :disabled="currentPage === 1">
        Previous
      </button>

      <span>No {{ currentPage }} / {{ totalPages }} Page</span>

      <button @click="nextPage" :disabled="currentPage === totalPages">
        Next
      </button>
    </div>
    <div class="footerbtn">
      <button @click="goBack">
        Return to Main Page 
      </button>
    </div>
     
  </div>
</template>

<style scoped>
.container {
  width: 80vw;
  height: 80vh;
  background: #2c2c2c;
  color: white;
  border-radius: 10px;

  display: flex;
  flex-direction: column;   /* ✅ 纵向布局 */
}

/* 顶部 */
.header {
  flex: 0 0 60px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 中间 */
.body {
  flex: 1;
  padding: 10px;
  width: 80vw;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

/* toolbar */
.toolbar {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* 表格容器（关键！） */
.table-wrapper {
  flex: 1;
  overflow-y: auto;   /* ✅ 超出滚动 */
}

/* 表格 */
table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  border: 1px solid #444;
  padding: 8px;
  text-align: center;
}

th {
  background: #3a3a3a;
}

/* 底部分页 */
.footer {
  width: 70vw;
  flex: 0 0 60px;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
  border-top: 1px solid #444;
}

.footerbtn {
  width: 70vw;
  flex: 0 0 60px;
  display: flex;
  justify-content: flex-end;
  align-items: flex-end;
  gap: 10px;
  padding-bottom: 1%;
}

/* 类型颜色 */
.type-info { color: #00aaff; }
.type-warning { color: orange; }
.type-error { color: red; }

/* 按钮 */
button {
  padding: 5px 10px;
  cursor: pointer;
}

button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>