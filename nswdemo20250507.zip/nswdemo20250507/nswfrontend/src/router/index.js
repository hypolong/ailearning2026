import { createRouter, createWebHistory } from "vue-router"

import Report from "../components/Report.vue"
import ReportList from "../components/Reportlist.vue"
import LogList from "../components/Loglist.vue"
import dashboard from "../components/charts.vue"

console.log("router loaded")
const routes = [
  {
    path: "/",
    component: Report
  },
  {
    path: "/report-list",
    component: ReportList
  },
  {
    path: "/log-list",
    component: LogList
  }
  ,
  {
    path: "/dashboard",
    component: dashboard
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router