from fastapi import FastAPI, Depends, HTTPException,WebSocket, WebSocketDisconnect
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime
from passlib.context import CryptContext
from fastapi.middleware.cors import CORSMiddleware
import asyncio

from opcua import Client

DATABASE_URL = "sqlite:///./productionrecords.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)

Base = declarative_base()

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True)
    password = Column(String)

class Workcenter(Base):
    __tablename__ = "workcenter_jobs"
    id = Column(Integer, primary_key=True)
    workcenter_name  = Column(String)
    workcenter_job  = Column(String)
    Part_Key = Column(String)
    operator  = Column(String)
    workcenter_status = Column(String)
    job_quantity  = Column(Integer)
    job_procedured = Column(Integer)
    job_status = Column(String)
    material_inventory = Column(Integer)
    
    
class ProductionRecord(Base):
    __tablename__ = "production_records"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    workcenter_id = Column(String)
    machine_id = Column(String)
    job_id = Column(String)
    quantity = Column(Integer)
    product_code = Column(String)
    material_inventory= Column(Integer, default=0)
    synced = Column(Integer, default=0)
    report_auto = Column(Integer, default=0)
    timestamp = Column(DateTime)
    created_at = Column(DateTime)

class WorkReport(Base):
    __tablename__ = "work_reports"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    record_id = Column(String)
    report_time = Column(DateTime)
    status = Column(String, default="pending")

class SystemConfig(Base):
    __tablename__ = "system_config"
    id = Column(Integer, primary_key=True)
    auto_report_enabled = Column(Integer, default=0)
    set_time = Column(DateTime)
    historia_flag = Column(Integer, default=0)

class SystemLogs(Base):
    __tablename__ = "system_logs"
    id = Column(Integer, primary_key=True)
    type = Column(String)
    message = Column(String)
    created_at = Column(DateTime)
    
def get_auto_report_enabled(db: Session):
    config = db.query(SystemConfig).filter(SystemConfig.id == 1).first()
    db.close()
    return config

def set_auto_report_enabled(db: Session, enabled: bool,set_datetime:DateTime):
    config = db.query(SystemConfig).filter(SystemConfig.id == 1).first()
    if config:
        config.auto_report_enabled = 1 if enabled else 0
        config.set_time=set_datetime
    else:
        config = SystemConfig(id=1, auto_report_enabled=1 if enabled else 0,set_time=set_datetime,historia_flag=config.historia_flag)
        db.add(config)
    db.commit()

def unset_historian_report_enabled(db: Session, enabled: bool):
    config = db.query(SystemConfig).filter(SystemConfig.id == 1).first()
    if config:
        config.historia_flag = 0 
    else:
        config = SystemConfig(id=1, auto_report_enabled=1 if enabled else 0,set_time=DateTime.now(),historia_flag=0)
        db.add(config)
    db.commit()

def set_historian_report_enabled(db: Session, enabled: bool):
    config = db.query(SystemConfig).filter(SystemConfig.id == 1).first()
    if config:
        config.historia_flag = 1
    else:
        config = SystemConfig(id=1, auto_report_enabled=1 if enabled else 0,set_time=DateTime.now(),historia_flag=1)
        db.add(config)
    db.commit()
    
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# init database
Base.metadata.create_all(bind=engine)

# 全局设置，上传数据到plex的频率
INTERVAL = 5  # 每5秒执行一次

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 获取plex数据写入DB********************************************************
import requests
from requests.auth import HTTPBasicAuth
from apscheduler.schedulers.background import BackgroundScheduler

def fetch_plex_data(Workcenter_Key:str):
    PLEX_API_1 = "https://nswmes.on.plex.com/api/datasources/10638/execute"
    PLEX_API_2 = "https://nswmes.on.plex.com/api/datasources/16878/execute"
    try:
        auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4")
         # API 1 body
        body1 = {
            "inputs": {
                "Workcenter_Key": Workcenter_Key
            }
        }

        # API 2 body
        body2 = {
            "inputs": {
                "Workcenter_Key": Workcenter_Key
            }
        }
        res1 = requests.post(PLEX_API_1,json=body1,auth=auth)
        res2 = requests.post(PLEX_API_2,json=body2,auth=auth)

        row1=(res1.json().get("tables",{})[0]).get("rows")[0]
        row2=(res2.json().get("tables",{})[0]).get("rows")[0]

        return row1, row2

    except Exception as e:
        print("get Plex workcenter data failed:", e)
        return None, None
           
def save_workcenterinfo_to_db(row1, row2):
    db: Session = SessionLocal()

    try:
        # print("=========================")
        # print(str(row1[0]) +"," + str(row1[22]) + "," + str(row2[15]) + "," + str(row1[34]) + "," + str(row1[21])+ "," + str( row1[58])+ "," +  str(row1[27]))
        
        # 获取这个workcenter的最后那条数据
        job_quantity=0 if row1[21] is None else int(row1[21])
        job_procedured=0 if row1[58] is None else int(row1[58])
        latest = db.query(Workcenter).filter(Workcenter.workcenter_name == str(row1[0])).order_by(Workcenter.id.desc()).first()
        if latest and latest.workcenter_job == str(row1[22]) and latest.operator == str(row2[15]) and latest.workcenter_status == str(row1[34]) and latest.job_quantity == job_quantity and latest.job_procedured == job_procedured and latest.job_status == str(row1[27]):
            print("no data changed,pass")
            return

        workcenter_info = Workcenter(
            workcenter_name=str(row1[0]) ,
            Part_Key=str(row1[5]) ,
            workcenter_job=str(row1[22]),
            operator=str(row2[15]),
            workcenter_status=str(row1[34]),
            job_quantity=  job_quantity,
            job_procedured= job_procedured,
            job_status=str(row1[27]),
            material_inventory=0
        )

        db.add(workcenter_info)
        db.commit()

    except Exception as e:
        print("write workcenter data to DB failed:", e)
        db.rollback()

    finally:
        print("final")
        db.close()

def collect_and_store():
    Workcenter_Keyset=[85277,85278,85279]
    for item in Workcenter_Keyset:
        data1, data2 = fetch_plex_data(item)
        if data1 and data2:
            save_workcenterinfo_to_db(data1, data2)
            print("workcenter data writed into DB finished")
        
scheduler = BackgroundScheduler()

def start_scheduler():
    scheduler.add_job(collect_and_store, "interval", seconds=15)
    # 启动OPC任务
    scheduler.add_job(opc_job, 'interval', seconds=30)
    scheduler.start()

@app.post("/api/collect")
def manual_collect():
    try:
        collect_and_store()
        return {"message": "采集成功"}
    except Exception as e:
        return {"error": str(e)}

# API for user login*****************************************************************************
@app.post("/api/login")
def login(username: str, password: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == username and User.password== password).first()
    
    loginlog=SystemLogs(
        type="login",
        message=username,
        created_at=datetime.now()
    )
    db.add(loginlog)
    db.commit()
    #**********************后续建议加密存储和验证
    # if not user or not pwd_context.verify(password, user.password):
    #     raise HTTPException(status_code=400, detail="用户名或密码错误")
    return {"msg": 1, "user_id": user.id}

@app.websocket("/ws/workinfo")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    last_id = None  # 用于判断是否有新数据

    Workcenter_name="pressing_shop"
    try:
        while True:
            db: Session = SessionLocal()
            try:
                msg = await asyncio.wait_for(websocket.receive_json(), timeout=1)
                # print("****************msg", msg)
                if msg.get("type") == "set_filter":
                    Workcenter_name = msg.get("value")
            except asyncio.TimeoutError:
                pass
            except Exception as e:
                print("====get erro msg:", e)
                break
                
            # print("=========Workcenter_name" + Workcenter_name)
            # 查询最新一条
            latest = (
                db.query(Workcenter).filter(Workcenter.workcenter_name == Workcenter_name)
                .order_by(Workcenter.id.desc())
                .first()
            )

            if latest and latest.id != last_id:
                last_id = latest.id

                # 转成 dict
                data = {
                    "workcenter_name": latest.workcenter_name,
                    "workcenter_job": latest.workcenter_job,
                    "product_code":latest.Part_Key,
                    "operator": latest.operator,
                    "workcenter_status": latest.workcenter_status,
                    "job_quantity": latest.job_quantity,
                    "job_procedured": latest.job_procedured,
                    "job_status": latest.job_status,
                    "material_inventory": latest.material_inventory,
                }

                await websocket.send_json(data)
            db.close()
            await asyncio.sleep(2) 

    except WebSocketDisconnect:
        print("WebSocket disconnected")
    
    except Exception as e:
        print("WebSocket erro:", e)
        
# API for record production
@app.post("/api/record")
def record(data: dict, db: Session = Depends(get_db)):
    # validate data
    if data.get("quantity") is None or int(data.get("quantity"))<1:
        return {"msg": 0}
    if data.get("job_id") is None or int(data.get("job_id"))<1:
        return {"msg": 0}
    if data.get("user_id") is None:
        return {"msg": 0}
    if data.get("workcenter_id") is None:
        return {"msg": 0}
    if data.get("machine_id") is None:
        return {"msg": 0}
    if data.get("job_id") is None:
        return {"msg": 0}
    
    # write data into db
    record = ProductionRecord(
        user_id=data.get("user_id"),
        workcenter_id=data.get("workcenter_id"),
        machine_id=data.get("machine_id"),
        job_id=data.get("job_id"),
        product_code=data.get("product_code"),
        quantity=data.get("quantity"),
        timestamp=datetime.now()
    )
    try:
        db.add(record)
        db.commit()
        return {"msg": 1}
    except:
        return {"msg": 0}

# API for reporting production records to plex
async def auto_report_task():
    # print("jinru==============")
    while True:
        db: Session = SessionLocal()
        auto_config=get_auto_report_enabled(db)
        AUTO_REPORT_ENABLED=auto_config.auto_report_enabled
        if AUTO_REPORT_ENABLED:
            print("begin to report...")
            try:
                # 查询未发送数据
                #此处注意，之前存在本地没有上传的生产产量也会自动上传
                #后续可用增加一个选项，是否自动上传历史数据的选项，然后根据只有点击自动开始后的才开始自动上传
                if auto_config.historia_flag:
                    records = db.query(ProductionRecord)\
                        .filter(ProductionRecord.synced == 0)\
                        .all()
                else:
                    records = db.query(ProductionRecord)\
                        .filter(ProductionRecord.synced == 0 and ProductionRecord.created_at>=auto_config.set_time)\
                        .all()

                for r in records:
                    if str(r.workcenter_id)=="pressing_shop":
                        Workcenter_ID="2d26cb8f-2bc3-4f5c-ad6a-e84a7d414cde"
                    elif str(r.workcenter_id)=="welding_shop":
                        Workcenter_ID="c05ae26a-025d-4b35-b013-a6d1ab94908c"
                    elif str(r.workcenter_id)=="painting_shop":
                        Workcenter_ID="224772fc-15ba-4674-92a4-6689211e00ba"
                    
                    #现在固定的指向 vehicle-seria-02，后续需要根据产品No，找到产品key，目前采用的是list parts接口获取后查询到的
                    Part_ID="794ae588-fa5e-4566-ad3d-c830269d342e"
                    
                    #load source inventory
                    if not fetch_plex_source_data(Workcenter_ID,Part_ID,float(r.quantity)):
                        return
                    success = await send_to_plex(r)
                    if success:
                        r.synced = 1
                        
                db.commit()

            except Exception as e:
                print("========********Auto report to plex failed:", e)
            finally:
                db.close()

        await asyncio.sleep(INTERVAL)

async def send_to_plex(record):
    db: Session = SessionLocal()
    if not get_auto_report_enabled(db).auto_report_enabled:
        return
    try:
        Workcenter_Key=85278
        if record.workcenter_id == "pressing_shop":
            Workcenter_Key=85277
        elif record.workcenter_id == "welding_shop":
            Workcenter_Key=85278
        elif record.workcenter_id == "painting_shop":
            Workcenter_Key=85279
        
        
        url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
        payload = {
            "inputs": {
                "Workcenter_Key": Workcenter_Key,
                "Quantity": record.quantity,
                "Start_New_Container": True
            }
        }
        headers = {
            "Content-Type": "application/json"
        }
        response = requests.post(
            url,
            auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
            json=payload,               
            headers=headers
        )
        # print("******************Status Code:", response.status_code)
        await asyncio.sleep(1)
            
        return True
    except Exception as e:
        print("Plex report failed:", e)
        return False

# 获取opc ua数据，作为过站信息，写入数据库
OPC_URL = "opc.tcp://localhost:62541"
client = Client(OPC_URL)
NODE_MAPPING = {
    "pressing_shop": {
        "job_quantity": "ns=1;s=[mitubishiPLC01]PaintingProductionCount"
    },
    "welding_shop": {
        "job_quantity": "ns=1;s=[mitubishiPLC01]PressProductionCount"
    },
    "painting_shop": {
        "job_quantity": "ns=1;s=[mitubishiPLC01]WeldingProductionCount"
        # "status": "ns=2;i=7"
    }
}

# 连接opc 服务器
def connect_opc():
    client.connect()
    print("✅ OPC UA Connected")
    
#断开opc服务器
def disconnect_opc():
    client.disconnect()

# # 订阅方式读取，变化才存取
# class SubHandler:
#     def datachange_notification(self, node, val, data):
#         print("📡 数据变化:", node, val)
#         # 在这里写入数据库

# def subscribe():
#     handler = SubHandler()
#     sub = client.create_subscription(1000, handler)

#     node = client.get_node("ns=2;i=2")
#     sub.subscribe_data_change(node)
    
# 读取数据
def read_workcenter_data():
    result = []
    for wc, nodes in NODE_MAPPING.items():
        try:
            job_node = client.get_node(nodes["job_quantity"])
            job_quantity = int(job_node.get_value())

            result.append({
                "workcenter_name": wc,
                "job_quantity": job_quantity
            })

        except Exception as e:
            print(f"❌ read {wc} failed:", e)

    return result

# 保存到数据库
def save_to_db(db, data_list):
   
    for item in data_list:
        #先查询当前对应的workcenter
        latest=db.query(Workcenter).filter(Workcenter.workcenter_name == item["workcenter_name"]).order_by(Workcenter.id.desc()).first()
        
        #后写入
        record = ProductionRecord(
            workcenter_id=latest.workcenter_name,
            machine_id = "PLC" + latest.workcenter_name,
            user_id=latest.operator,
            job_id = latest.workcenter_job,
            product_code = latest.Part_Key,
            quantity = item["job_quantity"],
            timestamp = datetime.now(),
            report_auto = 1,
            synced =0,
            created_at = datetime.now(),
            material_inventory= 0
        )
        db.add(record)

    db.commit()

# 配置opc 任务
def opc_job():
    db = SessionLocal()
    try:
        # 先确认是否OPC UA可用
        try:
            client.get_root_node()
        except:
            client.connect()
            
        data = read_workcenter_data()
        save_to_db(db, data)
        print("OPC data saved")
    finally:
        db.close()
 
# 启动循环器
@app.on_event("startup")
async def startup_event():
    start_scheduler()
    asyncio.create_task(auto_report_task())
    connect_opc()

@app.on_event("shutdown")
def shutdown():
    disconnect_opc()
    
@app.post("/auto-report/start")
def start_auto_report():
    db = SessionLocal()
    set_auto_report_enabled(db, True,datetime.now())
    db.close()
    return {"msg": 1}


@app.post("/auto-report/stop")
def stop_auto_report():
    db = SessionLocal()
    set_auto_report_enabled(db, False,datetime.now())
    db.close()
    return {"msg": 1}

@app.post("/report-historian/start")
def set_historian_report():
    db = SessionLocal()
    set_historian_report_enabled(db, True)
    db.close()
    return {"msg": 1}


@app.post("/report-historian/stop")
def unset_historian_report():
    db = SessionLocal()
    unset_historian_report_enabled(db, False)
    db.close()
    return {"msg": 1}

@app.get("/auto-report/status")
def get_status():
    db = SessionLocal()
    records = get_auto_report_enabled(db)
    enabled = records.auto_report_enabled
    histrorian = records.historia_flag
    db.close()  
    return {"enabled": True if enabled else False, "histrorian":True if histrorian else False}

#function for loading inventory ***************************
def fetch_plex_source_data(Workcenter_Key:str,production_key:str,report_count:float):
    PLEX_API_1 = "https://connect.plex.com/production/v1/control/workcenters/"+Workcenter_Key+"/loaded-source-inventory"
    PLEX_API_2 = "https://connect.plex.com/inventory/v1/inventory-tracking/containers?partId="+production_key
    PLEX_API_3 = "https://connect.plex.com/production/v1/control/workcenters/"+Workcenter_Key+"/loaded-source-inventory"

    try:
        headers = {
            "Content-Type": "application/json",
            "X-Plex-Connect-Api-Key":"wj1pzuvqwQuICDmQLaeYtD3q0W479vMr",
            "X-Plex-Connect-Tenant-Id":"6c7168ec-c430-494d-8fcc-4d789b447964"
        }
        
        # 先判断是否有对应数量的source
        res = requests.get(PLEX_API_1,headers=headers)
        containers_loaded=res.json()[0].get("containers")
        loaded_count=0.0
        containers_list=[]
        for items in containers_loaded:
            containers_list.append(items.get("serialNo"))
            loaded_count += items.get("quantity")
        
        #如果已经有足够的数量，就返回
        if loaded_count>=report_count:
            return True
        
        # 在获取可用的资源
        res = requests.get(PLEX_API_2,headers=headers)
        # 获取可用的container
        serial_num=""
        serial_list=[]
        for items in res.json():
            serial_num=items.get("serialNo")
            # 状态OK，数量少于需要数，不是已经load完毕的container，而且还不满足需求总数的，才load
            if items.get("containerStatus")=="OK" and items.get("quantity")<=report_count and serial_num not in containers_list:
                if  loaded_count<=report_count:
                    serial_list.append(serial_num)
                    loaded_count+=items.get("quantity")
                else:
                    break
        
        # 调用接口增加资源
        for items in serial_list:
            body = {
                "loadFIFO": True,
                "serialNo": items
            }
            res = requests.post(PLEX_API_3,headers=headers,json=body)
            
        return True

    except Exception as e:
        print("get Plex workcenter data failed:", e)
        return False
        
# API for record production  to db by manual"""""""""""""""
@app.post("/api/recordmanual")
def upload(data: dict, db: Session = Depends(get_db)):
    if str(data.get("workcenter_id"))=="pressing_shop":
        Workcenter_ID="2d26cb8f-2bc3-4f5c-ad6a-e84a7d414cde"
    elif str(data.get("workcenter_id"))=="welding_shop":
        Workcenter_ID="c05ae26a-025d-4b35-b013-a6d1ab94908c"
    elif str(data.get("workcenter_id"))=="painting_shop":
        Workcenter_ID="224772fc-15ba-4674-92a4-6689211e00ba"
    
    #现在固定的指向 vehicle-seria-02，后续需要根据产品No，找到产品key，目前采用的是list parts接口获取后查询到的
    Part_ID="794ae588-fa5e-4566-ad3d-c830269d342e"
    
    #load source inventory
    if not fetch_plex_source_data(Workcenter_ID,Part_ID,float(data.get("quantity"))):
        return {"msg": 0}
    
    # 只发当前的记录*************
    # 1.先记录
    # write data into db
    record = ProductionRecord(
        user_id=data.get("user_id"),
        workcenter_id=data.get("workcenter_id"),
        machine_id=data.get("machine_id"),
        job_id=data.get("job_id"),
        product_code=data.get("product_code"),
        quantity=data.get("quantity"),
        synced=0,
        report_auto=data.get("report_auto"),
        timestamp=datetime.now()
    )
    try:
        db.add(record)
        db.commit()       
    except Exception as e:
        print("Plex report failed:", e)
        return {"msg": 0}
    
    Workcenter_Key=85277
    if data.get("workcenter_id")== "pressing_shop":
        Workcenter_Key=85277
    elif data.get("workcenter_id") == "welding_shop":
        Workcenter_Key=85278
    elif data.get("workcenter_id") == "painting_shop":
        Workcenter_Key=85279
    
    # print("Workcenter_Key:",Workcenter_Key)
    # print("quantity",int(data.get("quantity")))
    # 2.记录成功后发送
    try:
        lastrecord = db.query(ProductionRecord).filter(ProductionRecord.user_id == data.get("user_id") and ProductionRecord.quantity==data.get("quantity") and ProductionRecord.report_auto == 0).order_by("id").limit(1)
    
        url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
        payload = {
            "inputs": {
                "Workcenter_Key": Workcenter_Key,
                "Quantity": int(data.get("quantity")),
                "Start_New_Container": True
            }
        }

        headers = {
                "Content-Type": "application/json"
        }
        
        response = requests.post(
            url,
            auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
            json=payload,               
            headers=headers
        )
        # print(response)
        if str(response.status_code)=="200":
            lastrecord.synced = 1
            db.commit()
            return {"msg": 1}
        else:
            return {"msg": 0}
    except Exception as e:
        print("Plex report failed:", e)
        return {"msg": 0}

from fastapi import Query
from typing import Optional

@app.get("/api/workinfolist")
def get_workinfo_list(is_sent: Optional[int] = Query(None), db: Session = Depends(get_db)):
    def to_dict(record):
        return { 
            "id": record.id,
            "workcenter_id": record.workcenter_id,
            "job_id": record.job_id,
            "user_id": record.user_id,
            "product_code": record.product_code,
            "quantity": record.quantity,
            "machine_id": record.machine_id,
            "report_auto":bool(record.report_auto),
            "is_sent": bool(record.synced),
            "timestamp": record.timestamp
    }
    query = db.query(ProductionRecord)

    if is_sent is not None:
        query = query.filter(ProductionRecord.synced == is_sent)
    results = query.order_by(ProductionRecord.id.desc()).all()
    data = [to_dict(r) for r in results]

    return data

@app.get("/api/logs")
def get_logs( page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    query = db.query(SystemLogs)
    print("=========1")
    total = query.count()
    rows = query.order_by(SystemLogs.id.desc()) \
                .offset((page - 1) * page_size) \
                .limit(page_size) \
                .all()

    print("=========2")
    data = [
        {
            "id": row.id,
            "type": row.type,
            "message": row.message,
            "created_at": row.created_at
        }
        for row in rows
    ]

    return {
        "data": data,
        "total": total,
        "page": page,
        "page_size": page_size
    }

# API for get workcenter info
@app.get("/api/workcenter_jobs")
def get_workcenterinfo(workcenter_key: str):
    db = SessionLocal()
    records=""
    if workcenter_key=="all":
        records=db.query(Workcenter).order_by(Workcenter.id.desc()).limit(30).all()
    else:
        records=db.query(Workcenter).filter(Workcenter.workcenter_name == workcenter_key).order_by(Workcenter.id.desc()).limit(30).all()
        
    categories = []
    values = []

    for r in records:
        categories.append(r.id)
        values.append(r.job_quantity)
        
    db.close()
    returnJason= {
        "categories": categories,
        "series": [
            {
                "name": "production plan",
                "data": values
            }
        ]
    }
    return returnJason

# API for get production records
@app.get("/api/production_records")
def get_productions( production_key:str): 
    db = SessionLocal()
    records=""
    if production_key=="all":
        records = (
            db.query(ProductionRecord)
            .order_by(ProductionRecord.id.desc())
            .limit(30)
            .all()
        )
    else:
        records = (
            db.query(ProductionRecord)
            .filter(ProductionRecord.product_code == production_key)
            .order_by(ProductionRecord.id.desc())
            .limit(30)
            .all()
        )
        
    categories = []
    values = []

    for r in records:
        categories.append(int(r.timestamp.timestamp() * 1000))
        values.append(r.quantity)
        
    db.close()
    returnJason= {
        "categories": categories,
        "series": [
            {
                "name": "production actual",
                "data": values
            }
        ]
    }
    return returnJason