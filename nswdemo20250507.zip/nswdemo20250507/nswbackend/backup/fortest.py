# library for fastAPI and socket
from fastapi import FastAPI, Depends, HTTPException,WebSocket, WebSocketDisconnect
from fastapi import Query
from typing import Optional

# library for sqlite
from sqlalchemy import create_engine, Column, Integer, String, DateTime,event,text
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker, Session

from passlib.context import CryptContext
from fastapi.middleware.cors import CORSMiddleware

#library for asy multi-task
import asyncio

# library for api request
import requests
from requests.auth import HTTPBasicAuth

# library for opc
from opcua import Client

# library for datetime getting
from datetime import datetime

#library for httpx request
import httpx

#sqllite db path and engine setting
DATABASE_URL = "sqlite:///./productionrecords.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()
# not using for now
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# init database
Base.metadata.create_all(bind=engine)

#sqlite paranel auto
@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL;")
    cursor.execute("PRAGMA synchronous=NORMAL;")
    cursor.execute("PRAGMA busy_timeout=3000;")
    cursor.close()

# function to create a db connecting to sqlite
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
        
# data modles
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True)
    password = Column(String)

class Workcenter(Base):
    __tablename__ = "workcenter_jobs"
    id = Column(Integer, primary_key=True)
    workcenter_name  = Column(String)
    workcenter_job  = Column(String)
    Part_Key = Column(String)
    operator  = Column(String)
    workcenter_status = Column(String)
    job_quantity  = Column(Integer)
    job_procedured = Column(Integer)
    job_status = Column(String)
    material_inventory = Column(Integer)
    
    
class ProductionRecord(Base):
    __tablename__ = "production_records"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    workcenter_id = Column(String)
    machine_id = Column(String)
    job_id = Column(String)
    quantity = Column(Integer)
    product_code = Column(String)
    material_inventory= Column(Integer, default=0)
    synced = Column(Integer, default=0)
    report_auto = Column(Integer, default=0)
    timestamp = Column(DateTime)
    created_at = Column(DateTime)

class WorkReport(Base):
    __tablename__ = "work_reports"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    record_id = Column(String)
    report_time = Column(DateTime)
    status = Column(String, default="pending")

class SystemConfig(Base):
    __tablename__ = "system_config"
    id = Column(Integer, primary_key=True)
    workcenter_id = Column(String)
    auto_report_enabled = Column(Integer, default=0)
    set_time = Column(DateTime)
    historia_flag = Column(Integer, default=0)

class SystemLogs(Base):
    __tablename__ = "system_logs"
    id = Column(Integer, primary_key=True)
    type = Column(String)
    message = Column(String)
    created_at = Column(DateTime)

#init fastAPI
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# function to get auto report flag
def get_auto_report_enabled(db: Session):
    config = db.query(SystemConfig).filter(SystemConfig.auto_report_enabled == 1).all()
    db.close()
    return config

# function to set auto report flag
def set_auto_report_enabled(db: Session, enabled: bool,set_datetime:DateTime):
    config = db.query(SystemConfig).filter(SystemConfig.id == 1).first()
    if config:
        config.auto_report_enabled = 1 if enabled else 0
        config.set_time=set_datetime
    else:
        config = SystemConfig(id=1, auto_report_enabled=1 if enabled else 0,set_time=set_datetime,historia_flag=config.historia_flag)
        db.add(config)
    db.commit()

#function for loading plex inventory ***************************
async def fetch_plex_source_data(Workcenter_Key:str,production_key:str,report_count:float):
    PLEX_API_1 = "https://connect.plex.com/production/v1/control/workcenters/"+Workcenter_Key+"/loaded-source-inventory"
    PLEX_API_2 = "https://connect.plex.com/inventory/v1/inventory-tracking/containers?partId="+production_key
    PLEX_API_3 = "https://connect.plex.com/production/v1/control/workcenters/"+Workcenter_Key+"/loaded-source-inventory"

    try:
        headers = {
            "Content-Type": "application/json",
            "X-Plex-Connect-Api-Key":"wj1pzuvqwQuICDmQLaeYtD3q0W479vMr",
            "X-Plex-Connect-Tenant-Id":"6c7168ec-c430-494d-8fcc-4d789b447964"
        }
        
        # justify firstly if the source is enough
        res = requests.get(PLEX_API_1,headers=headers)
        containers_loaded=res.json()[0].get("containers")
        loaded_count=0.0
        containers_list=[]
        for items in containers_loaded:
            containers_list.append(items.get("serialNo"))
            loaded_count += items.get("quantity")
        
        #if enoough then return
        if loaded_count>=report_count:
            return True
        
        # else get the avalable resource
        res = requests.get(PLEX_API_2,headers=headers)
        # get containers
        serial_num=""
        serial_list=[]
        for items in res.json():
            serial_num=items.get("serialNo")
            # status is OK,count is less the the needed 
            # and not already load container,and if not satisfied the needed count ,then load
            if items.get("containerStatus")=="OK" and items.get("quantity")<=report_count and serial_num not in containers_list:
                if  loaded_count<=report_count:
                    serial_list.append(serial_num)
                    loaded_count+=items.get("quantity")
                else:
                    break
        
        # call the plex API to add source to the job in this workcenter
        for items in serial_list:
            body = {
                "loadFIFO": True,
                "serialNo": items
            }
            res = requests.post(PLEX_API_3,headers=headers,json=body)
            
        return True

    except Exception as e:
        print("get Plex workcenter data failed:", e)
        return False

async def send_to_plex(record):
    db: Session = SessionLocal()
    try:
        Workcenter_Key=85278
        if record.workcenter_id == "pressing_shop":
            Workcenter_Key=85277
        elif record.workcenter_id == "welding_shop":
            Workcenter_Key=85278
        elif record.workcenter_id == "painting_shop":
            Workcenter_Key=85279
        
        url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
        payload = {
            "inputs": {
                "Workcenter_Key": Workcenter_Key,
                "Quantity": record.total_qty,
                "Start_New_Container": True
            }
        }
        headers = {
            "Content-Type": "application/json"
        }
        response = requests.post(
            url,
            auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
            json=payload,               
            headers=headers
        )
        print("Status Code:", response.status_code)
        await asyncio.sleep(1)
            
        return True
    except Exception as e:
        print("Plex report failed:", e)
        return False
           
# API for reporting production records to plex
async def auto_report_task():
    print("come to herer")
    while True:
        db: Session = SessionLocal()
        record_configs=get_auto_report_enabled(db)
        #identify if send data automatically and need to send the hostorian
        print("begin to report...")
        for r in record_configs:   
            historian_config=r.historia_flag
            flag_set_time=r.set_time
            update_sql=""

            try:
                #search the unsent data
                #use the historian flag to identify sending historian records or not
                if not historian_config:
                    records =  db.execute(text("SELECT workcenter_id, SUM(quantity) AS total_qty from production_records WHERE workcenter_id='" + r.workcenter_id + "' AND synced = 0 AND created_at >= '" +  str(flag_set_time) + "' GROUP BY workcenter_id;"))
                    update_sql = "UPDATE production_records SET synced = 1 WHERE  workcenter_id='" + r.workcenter_id + "' AND synced = 0 AND  created_at >= '" +  str(flag_set_time) + "';"
                else:
                    records =  db.execute(text("SELECT workcenter_id, SUM(quantity) AS total_qty from production_records WHERE  workcenter_id='" + r.workcenter_id + "' AND synced = 0 GROUP BY workcenter_id;"))
                    update_sql = "UPDATE production_records SET synced = 1 WHERE  workcenter_id='" + r.workcenter_id + "' AND synced = 0;"
                rows = records.fetchall()
                # actually there is only 1  or 0 row
                if len(rows)>0:
                    # point to vehicle-seria-02 for now, need to change in the future
                    # use the plex API "list parts" to get the part id
                    Part_ID="794ae588-fa5e-4566-ad3d-c830269d342e"
                    if str(rows[0].workcenter_id)=="pressing_shop":
                        Workcenter_ID="2d26cb8f-2bc3-4f5c-ad6a-e84a7d414cde"
                    elif str(rows[0].workcenter_id)=="welding_shop":
                        Workcenter_ID="c05ae26a-025d-4b35-b013-a6d1ab94908c"
                    elif str(rows[0].workcenter_id)=="painting_shop":
                        Workcenter_ID="224772fc-15ba-4674-92a4-6689211e00ba"

                    #load source inventory firstly
                    if not await fetch_plex_source_data(Workcenter_ID,Part_ID,float(rows[0].total_qty)):
                        return
                    # then send production records
                    print("begin to report")
                    success = await send_to_plex(rows[0])
                    
                    if success:
                        db.execute(text(update_sql))
                            
                    db.commit()

            except Exception as e:
                print("========Auto report to plex failed:", e)
            finally:
                db.close()
        await asyncio.sleep(5)

@app.on_event("startup")
async def startup_event():        
    asyncio.create_task(auto_report_task())