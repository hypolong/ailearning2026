import requests
from requests.auth import HTTPBasicAuth

def standard_add_production(Workcenter_Key:int,report_count:float):
    # 先判断是否要新增container，也就是先判断当前可持续写入储量的container是否存在，而且没有达到标准数量
    # =================还没有找到对应的接口 20351可以获取所有的这个job对应的workcenter的container清单
    url = "https://nswmes.on.plex.com/api/datasources/20351/execute"
    payload = {
        "inputs": {
            "Container_Status": "OK",
             "Job_No": "23"
        }
    }

    headers = {
            "Content-Type": "application/json"
    }
    
    response = requests.post(
        url,
        auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
        json=payload,               
        headers=headers
    )

    lastrow=""
    if str(response.status_code)=="200":
        lastrow= max(response.json()["tables"][0]["rows"], key=lambda x: x[1])
    
    print("lastrow",lastrow[-1])

    return lastrow

    #先查询16878获取"Part_Key": 10369804, "Part_Operation_Key": 65234423
    url = "https://nswmes.on.plex.com/api/datasources/16878/execute"
    payload = {
        "inputs": {
            "Workcenter_Key": Workcenter_Key
        }
    }

    headers = {
            "Content-Type": "application/json"
    }
    
    response = requests.post(
        url,
        auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
        json=payload,               
        headers=headers
    )
    if str(response.status_code)=="200":
    #    print(response.json()["tables"][0]["rows"])
        Part_Key=response.json()["tables"][0]["rows"][0][17]
        Part_Operation_Key=response.json()["tables"][0]["rows"][0][18]
      
        #再查询4658获取standard数量
        url = "https://nswmes.on.plex.com/api/datasources/4658/execute"
        payload = {
            "inputs": {
                "Part_Key": Part_Key,
                "Part_Operation_Key": Part_Operation_Key,
                "Workcenter_Key": Workcenter_Key
            }
        }
        response = requests.post(
            url,
            auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
            json=payload,               
            headers=headers
        )
        if str(response.status_code)=="200":
            # 然后根据标准数量进行container的拆分
            print("ok")
            return float(response.json()["outputs"]["Standard_Quantity"])
        else:
            print(response.json())
            return "erro"
        
#查询最后一个container的状态


# 查询标准数量
print(standard_add_production(85277,2))