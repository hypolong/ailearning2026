import sqlite3

print("hello")
# 连接时自动创建数据库文件
conn = sqlite3.connect('productionrecords.db')

# 创建示例表
cursor = conn.cursor()
cursor.execute('''
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
''')

cursor.execute('''
CREATE TABLE workcenter_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workcenter_name TEXT,
    workcenter_job TEXT,
    Part_Key TEXT,
    operator TEXT,
    workcenter_status TEXT,
    job_quantity INTEGER,
    job_procedured INTEGER,
    job_status TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
''')

cursor.execute('''
CREATE TABLE workcenter_machine_mapping (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workcenter_id TEXT NOT NULL,
    job_id TEXT NOT NULL
);
''')

cursor.execute('''
CREATE TABLE production_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workcenter_id TEXT NOT NULL,
    machine_id TEXT,
    user_id TEXT NOT NULL,
    job_id TEXT NOT NULL,
    product_code TEXT,
    quantity INTEGER NOT NULL,
    timestamp DATETIME NOT NULL,
    report_auto INTEGER DEFAULT 0,   -- 是否自动上传到Plex
    synced INTEGER DEFAULT 0,   -- 是否已上传到Plex
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
''')

cursor.execute('''
CREATE TABLE work_reports_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    record_id INTEGER,
    quantity INTEGER,
    report_time DATETIME,
    status TEXT DEFAULT 'pending',  -- pending / uploaded
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
''')

cursor.execute('''
CREATE TABLE system_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT,
    message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
''')

conn.commit()
conn.close()
print("数据库创建成功：mydatabase.db")
