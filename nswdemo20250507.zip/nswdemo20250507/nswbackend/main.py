# library for fastAPI and socket
from fastapi import FastAPI, Depends, HTTPException,WebSocket, WebSocketDisconnect
from fastapi import Query
from typing import Optional
import uvicorn

# library for sqlite
from sqlalchemy import create_engine, Column, Integer, String, DateTime,event,text
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker, Session

from passlib.context import CryptContext
from fastapi.middleware.cors import CORSMiddleware

#library for asy multi-task
import asyncio

# library for api request
import requests
from requests.auth import HTTPBasicAuth

# library for opc
from opcua import Client

# library for datetime getting
from datetime import datetime

#library for httpx request
import httpx

#library for get paras from frontend
from pydantic import BaseModel

#sqllite db path and engine setting
DATABASE_URL = "sqlite:///./productionrecords.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()
# not using for now
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# init database
Base.metadata.create_all(bind=engine)

#sqlite paranel auto
@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL;")
    cursor.execute("PRAGMA synchronous=NORMAL;")
    cursor.execute("PRAGMA busy_timeout=3000;")
    cursor.close()

# function to create a db connecting to sqlite
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
        
# data modles
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True)
    password = Column(String)

class Workcenter(Base):
    __tablename__ = "workcenter_jobs"
    id = Column(Integer, primary_key=True)
    workcenter_name  = Column(String)
    workcenter_job  = Column(String)
    Part_Key = Column(String)
    operator  = Column(String)
    workcenter_status = Column(String)
    job_quantity  = Column(Integer)
    job_procedured = Column(Integer)
    job_status = Column(String)
    material_inventory = Column(Integer)
    
    
class ProductionRecord(Base):
    __tablename__ = "production_records"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    workcenter_id = Column(String)
    machine_id = Column(String)
    job_id = Column(String)
    quantity = Column(Integer)
    product_code = Column(String)
    material_inventory= Column(Integer, default=0)
    synced = Column(Integer, default=0)
    report_auto = Column(Integer, default=0)
    timestamp = Column(DateTime)
    created_at = Column(DateTime)

class WorkReport(Base):
    __tablename__ = "work_reports"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    record_id = Column(String)
    report_time = Column(DateTime)
    status = Column(String, default="pending")

class SystemConfig(Base):
    __tablename__ = "system_config"
    id = Column(Integer, primary_key=True)
    workcenter_id = Column(String)
    auto_report_enabled = Column(Integer, default=0)
    set_time = Column(DateTime)
    historia_flag = Column(Integer, default=0)

class SystemLogs(Base):
    __tablename__ = "system_logs"
    id = Column(Integer, primary_key=True)
    type = Column(String)
    message = Column(String)
    created_at = Column(DateTime)

#init fastAPI
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://10.16.52.148:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# function to get auto report flag
def get_auto_report_enabled(db: Session,workcenter_key:str):
    if workcenter_key=="all":
        config = db.query(SystemConfig).filter().all()
    else:
        config = db.query(SystemConfig).filter(SystemConfig.workcenter_id==workcenter_key).all()
    db.close()
    return config

# function to set auto report flag
def set_auto_report_enabled(db: Session, enabled: bool,set_datetime:DateTime,workcenter_key:str):
    try:
        config = 1 if enabled else 0
        print("UPDATE system_config SET auto_report_enabled = "+ str(config) +", set_time='" + str(set_datetime) +"' " + "where workcenter_id='" + workcenter_key + "';")
        if workcenter_key=="all":
            db.execute(text("UPDATE system_config SET auto_report_enabled = "+ str(config) +", set_time='" + str(set_datetime) +"';" ))      
        elif not workcenter_key=="":
            db.execute(text("UPDATE system_config SET auto_report_enabled = "+ str(config) +", set_time='" + str(set_datetime) +"' " + "where workcenter_id='" + workcenter_key + "';"))     
        db.commit()
        return True
    except:
        return False

# function to set historian record report flag
def get_historian_report_enabled(db: Session, workcenter_key:str):
    if workcenter_key=="all":
        config = db.query(SystemConfig).filter().all()
    else:
        config = db.query(SystemConfig).filter(SystemConfig.workcenter_id==workcenter_key).all()
    db.close()
    return config
    
# function to unset historian record report flag
def set_historian_report_enabled(db: Session, enabled: bool,workcenter_key:str):
    try:
        config = 1 if enabled else 0
        if workcenter_key=="all":
            db.execute(text("UPDATE system_config SET historia_flag = "+ str(config) +";" ))      
        elif not workcenter_key=="":
            db.execute(text("UPDATE system_config SET historia_flag = "+ str(config) + " where workcenter_id='" + workcenter_key + "';"))     
        db.commit()
        return True
    except:
        return False
    
# get date and write into sqlite********************************************************          
def save_workcenterinfo_to_db(row1, row2):
    db: Session = SessionLocal()

    try: 
        job_quantity=0 if row1[21] is None else int(row1[21])
        job_procedured=0 if row1[58] is None else int(row1[58])
        latest = db.query(Workcenter).filter(Workcenter.workcenter_name == str(row1[0])).order_by(Workcenter.id.desc()).first()
        if latest and latest.workcenter_job == str(row1[22]) and latest.operator == str(row2[15]) and latest.workcenter_status == str(row1[34]) and latest.job_quantity == job_quantity and latest.job_procedured == job_procedured and latest.job_status == str(row1[27]):
            # print("no data changed,pass")
            return

        workcenter_info = Workcenter(
            workcenter_name=str(row1[0]) ,
            Part_Key=str(row1[5]) ,
            workcenter_job=str(row1[22]),
            operator=str(row2[15]),
            workcenter_status=str(row1[34]),
            job_quantity=  job_quantity,
            job_procedured= job_procedured,
            job_status=str(row1[27]),
            material_inventory=0
        )

        db.add(workcenter_info)
        db.commit()

    except Exception as e:
        print("write workcenter data to DB failed:", e)
        db.rollback()

    finally:
        # print("final")
        db.close()

async def plex_loop():
    async with httpx.AsyncClient(timeout=10) as client:
        while True:
            try:
                for key in [85277, 85278, 85279]:
                    body = {"inputs": {"Workcenter_Key": key}}

                    res1 = await client.post(
                        "https://nswmes.on.plex.com/api/datasources/10638/execute",
                        json=body,
                        auth=("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4")
                    )

                    res2 = await client.post(
                        "https://nswmes.on.plex.com/api/datasources/16878/execute",
                        json=body,
                        auth=("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4")
                    )

                    row1 = res1.json()["tables"][0]["rows"][0]
                    row2 = res2.json()["tables"][0]["rows"][0]

                    db = SessionLocal()
                    try:
                        save_workcenterinfo_to_db(row1, row2)
                    finally:
                        db.close()

                # print("workcenter info from Plex updated")

            except Exception as e:
                print("Plex error:", e)

            await asyncio.sleep(10)
        
# API for user login*****************************************************************************
@app.post("/api/login")
def login(username: str, password: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == username and User.password== password).first()
    
    if not user:
        return {"msg": 0, "error": "username or password erro"}
    
    loginlog=SystemLogs(
        type="login",
        message=username,
        created_at=datetime.now()
    )
    db.add(loginlog)
    db.commit()
    #**********************need to encry the password in the future
    # if not user or not pwd_context.verify(password, user.password):
    #     raise HTTPException(status_code=400, detail="password or username erro")
    return {"msg": 1, "user_id": user.id}

@app.websocket("/ws/workinfo")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    last_id = None  #for identify new data

    Workcenter_name="pressing_shop"
    try:
        while True:
            db: Session = SessionLocal()
            try:
                msg = await asyncio.wait_for(websocket.receive_json(), timeout=1)
                if msg.get("type") == "set_filter":
                    Workcenter_name = msg.get("value")
            except asyncio.TimeoutError:
                pass
            except WebSocketDisconnect:
                print("WebSocket disconnected")
                break
            except Exception as e:
                print("====get erro msg====:", e)
                break
                
            # get the latest record for this workcenter
            latest = (
                db.query(Workcenter).filter(Workcenter.workcenter_name == Workcenter_name)
                .order_by(Workcenter.id.desc())
                .first()
            )

            if latest and latest.id != last_id:
                last_id = latest.id

                # transform to dict
                data = {
                    "workcenter_name": latest.workcenter_name,
                    "workcenter_job": latest.workcenter_job,
                    "product_code":latest.Part_Key,
                    "operator": latest.operator,
                    "workcenter_status": latest.workcenter_status,
                    "job_quantity": latest.job_quantity,
                    "job_procedured": latest.job_procedured,
                    "job_status": latest.job_status,
                    "material_inventory": latest.material_inventory,
                }

                await websocket.send_json(data)
            db.close()
            await asyncio.sleep(2) 

    except WebSocketDisconnect:
        print("WebSocket disconnected")
    
    except Exception as e:
        print("WebSocket erro:", e)
        
# API for reporting production records to plex
# API for reporting production records to plex
async def auto_report_task():
    while True:
        db: Session = SessionLocal()
        record_configs=get_auto_report_enabled(db,"all")
        #identify if send data automatically and need to send the hostorian
        print("begin to report...")
        for r in record_configs:   
            historian_config=r.historia_flag
            flag_set_time=r.set_time
            update_sql=""

            if not r.auto_report_enabled:
                continue
            try:
                #search the unsent data
                #use the historian flag to identify sending historian records or not
                if not historian_config:
                    records =  db.execute(text("SELECT workcenter_id, SUM(quantity) AS total_qty from production_records WHERE workcenter_id='" + r.workcenter_id + "' AND synced = 0 AND created_at >= '" +  str(flag_set_time) + "' GROUP BY workcenter_id;"))
                    update_sql = "UPDATE production_records SET synced = 1 WHERE  workcenter_id='" + r.workcenter_id + "' AND synced = 0 AND  created_at >= '" +  str(flag_set_time) + "';"
                else:
                    records =  db.execute(text("SELECT workcenter_id, SUM(quantity) AS total_qty from production_records WHERE  workcenter_id='" + r.workcenter_id + "' AND synced = 0 GROUP BY workcenter_id;"))
                    update_sql = "UPDATE production_records SET synced = 1 WHERE  workcenter_id='" + r.workcenter_id + "' AND synced = 0;"
                rows = records.fetchall()
                # actually there is only 1  or 0 row
                if len(rows)>0:
                    # point to vehicle-seria-02 for now, need to change in the future
                    # use the plex API "list parts" to get the part id
                    Part_ID="794ae588-fa5e-4566-ad3d-c830269d342e"
                    if str(rows[0].workcenter_id)=="pressing_shop":
                        Workcenter_ID="2d26cb8f-2bc3-4f5c-ad6a-e84a7d414cde"
                    elif str(rows[0].workcenter_id)=="welding_shop":
                        Workcenter_ID="c05ae26a-025d-4b35-b013-a6d1ab94908c"
                    elif str(rows[0].workcenter_id)=="painting_shop":
                        Workcenter_ID="224772fc-15ba-4674-92a4-6689211e00ba"

                    #load source inventory firstly
                    if not fetch_plex_source_data(Workcenter_ID,Part_ID,float(rows[0].total_qty)):
                        return
                    # then send production records
                    # print("begin to report")
                    success = await send_to_plex(rows[0])
                    
                    if success:
                        db.execute(text(update_sql))
                        db.commit()
                    print("report completed!")
            except Exception as e:
                print("========Auto report to plex failed:", e)
            finally:
                db.close()
        await asyncio.sleep(5)

async def send_to_plex(record):
    db: Session = SessionLocal()
    try:
        Workcenter_Key=85278
        if record.workcenter_id == "pressing_shop":
            Workcenter_Key=85277
        elif record.workcenter_id == "welding_shop":
            Workcenter_Key=85278
        elif record.workcenter_id == "painting_shop":
            Workcenter_Key=85279
        
        # API for add production records to plex
        url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
        payload = {
            "inputs": {
                "Workcenter_Key": Workcenter_Key,
                "Quantity": int(record.total_qty),
                "Start_New_Container": True
            }
        }
        headers = {
            "Content-Type": "application/json"
        }
        response = requests.post(
            url,
            auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
            json=payload,               
            headers=headers
        )
        # print("Status Code:", response.status_code)
        await asyncio.sleep(1)
        if str(response.status_code)==200:
            return True
        else:
            return False
    except Exception as e:
        print("Plex report failed:", e)
        return False

# connect to opc ua server to get PLC data and write into sqlite*********************************
OPC_URL = "opc.tcp://10.16.52.148:62541"
tasks = []
# read opc ua data
def read_opc_blocking():
    client = Client(OPC_URL)
    result = []

    NODE_MAPPING = {
        "pressing_shop": "ns=1;s=[mitubishiQ]PaintingProductionCount",
        "welding_shop": "ns=1;s=[mitubishiQ]PressProductionCount",
        "painting_shop": "ns=1;s=[mitubishiQ]WeldingProductionCount",
    }

    try:
        client.connect()

        for wc, node_id in NODE_MAPPING.items():
            try:
                node = client.get_node(node_id)
                val = int(node.get_value())
                result.append({
                    "workcenter_name": wc,
                    "job_quantity": val
                })
            except Exception as e:
                print("OPC read error:", wc, e)

    finally:
        client.disconnect()

    return result

# save plc data to sqlite
def save_to_db(db, data_list):
   
    for item in data_list:
        #sear the workcenter info first
        latest=db.query(Workcenter).filter(Workcenter.workcenter_name == item["workcenter_name"]).order_by(Workcenter.id.desc()).first()
        
        #then write into DB
        record = ProductionRecord(
            workcenter_id=latest.workcenter_name,
            machine_id = "PLC" + latest.workcenter_name,
            user_id=latest.operator,
            job_id = latest.workcenter_job,
            product_code = latest.Part_Key,
            quantity = item["job_quantity"],
            timestamp = datetime.now(),
            report_auto = 1,
            synced =0,
            created_at = datetime.now(),
            material_inventory= 0
        )
        db.add(record)

    db.commit()

# opc data getting loop
async def opc_loop():
    while True:
        try:
            data = await asyncio.wait_for(
                asyncio.to_thread(read_opc_blocking),
                timeout=10
            )

            db = SessionLocal()
            try:
                for item in data:
                    save_to_db(db, [item])
                print("OPC data updated")
            finally:
                db.close()

        except asyncio.TimeoutError:
            print("OPC timeout")
        except Exception as e:
            print("OPC loop error:", e)

        # read by 15 seconds
        await asyncio.sleep(15)
 
# start all loops
@app.on_event("startup")
async def startup_event():
    #①get the plex workcenter info
    tasks.append(asyncio.create_task(plex_loop()))
    
    #②get PLC production recordings
    tasks.append(asyncio.create_task(opc_loop()))
    
    #③upload production records
    tasks.append(asyncio.create_task(auto_report_task()))

#stop all tasks   
@app.on_event("shutdown")
async def shutdown():
    print("==============system shutting down...")
    for t in tasks:
        t.cancel()

    await asyncio.gather(*tasks, return_exceptions=True)

class AutoReportRequest(BaseModel):
    workcenter_key: str
# api for setting auto report flag on
@app.post("/auto-report/start")
def start_auto_report(req: AutoReportRequest):
    # print("**************workcenter_key",req.workcenter_key)
    db = SessionLocal()
    if set_auto_report_enabled(db, True,datetime.now(),req.workcenter_key):
        db.close()
        return {"msg": 1}
    else:
        db.close()
        return {"msg": 0}

# api for setting auto report flag off
@app.post("/auto-report/stop")
def stop_auto_report(req: AutoReportRequest):
    db = SessionLocal()
    if set_auto_report_enabled(db, False,datetime.now(),req.workcenter_key):
        db.close()
        return {"msg": 1}
    else:
        db.close()
        return {"msg": 0}

# api for setting historian report flag on
@app.post("/report-historian/start")
def set_historian_report(req: AutoReportRequest):
    db = SessionLocal()
    if set_historian_report_enabled(db, True,req.workcenter_key):
        db.close()
        return {"msg": 1}
    else:
        db.close()
        return {"msg": 0}

# api for setting historian report flag off
@app.post("/report-historian/stop")
def unset_historian_report(req: AutoReportRequest):
    db = SessionLocal()
    if set_historian_report_enabled(db, False,req.workcenter_key):
        db.close()
        return {"msg": 1}
    else:
        db.close()
        return {"msg": 0}

# api for getting flags
@app.post("/auto-report/status")
def get_status(req: AutoReportRequest):
    db = SessionLocal()
    records = get_auto_report_enabled(db,str(req.workcenter_key))

    if not records:
        return {"msg":0}
    enabled = records[0].auto_report_enabled
    histrorian = records[0].historia_flag
    db.close()
    return {"enabled": True if enabled else False, "histrorian":True if histrorian else False}

#function for loading plex inventory ***************************
def fetch_plex_source_data(Workcenter_Key:str,production_key:str,report_count:float):
    PLEX_API_1 = "https://connect.plex.com/production/v1/control/workcenters/"+Workcenter_Key+"/loaded-source-inventory"
    PLEX_API_2 = "https://connect.plex.com/inventory/v1/inventory-tracking/containers?partId="+production_key
    PLEX_API_3 = "https://connect.plex.com/production/v1/control/workcenters/"+Workcenter_Key+"/loaded-source-inventory"

    try:
        headers = {
            "Content-Type": "application/json",
            "X-Plex-Connect-Api-Key":"wj1pzuvqwQuICDmQLaeYtD3q0W479vMr",
            "X-Plex-Connect-Tenant-Id":"6c7168ec-c430-494d-8fcc-4d789b447964"
        }
        
        # justify firstly if the source is enough
        res = requests.get(PLEX_API_1,headers=headers)
        containers_loaded=res.json()[0].get("containers")
        loaded_count=0.0
        containers_list=[]
        for items in containers_loaded:
            containers_list.append(items.get("serialNo"))
            loaded_count += items.get("quantity")
        
        # print("loaded_count",loaded_count)
        # print("report_count",report_count)
        #if enoough then return
        if loaded_count>=report_count:
            return True
        
        # else get the avalable resource
        res = requests.get(PLEX_API_2,headers=headers)
        # get containers
        serial_num=""
        serial_list=[]
        for items in res.json():
            serial_num=items.get("serialNo")
            # status is OK,count is less the the needed 
            # and not already load container,and if not satisfied the needed count ,then load
            if items.get("containerStatus")=="OK" and items.get("quantity")<=report_count and serial_num not in containers_list:
                if  loaded_count<=report_count:
                    serial_list.append(serial_num)
                    loaded_count+=items.get("quantity")
                else:
                    break
        
        # call the plex API to add source to the job in this workcenter
        for items in serial_list:
            body = {
                "loadFIFO": True,
                "serialNo": items
            }
            res = requests.post(PLEX_API_3,headers=headers,json=body)
            
        return True

    except Exception as e:
        print("get Plex workcenter data failed:", e)
        return False
    
 # 这里是：是否新增container的判断==================================暂时未采纳===================默认就是新增到最后一个空的container
# 如果最后的这个container状态为not full，那么就新增到旧的container，但是如果新增的数量超出旧的，那么就把新的数量加入新的container，并发布label
# 因此需要一个专门的函数来处理这个部分，当一次性汇报的数量很多的时候，可能需要生成多个container并发布label，实际运用中需要提醒用户，当数量很大的时候
# plex中不支持一次性批量录入后，自动按照标准的数量生成container，只能按照标准数量一个个调用
#        
def query_standard_quality(Workcenter_Key:int,report_count:float):
    #先查询16878获取"Part_Key": 10369804, "Part_Operation_Key": 65234423
    url = "https://nswmes.on.plex.com/api/datasources/16878/execute"
    payload = {
        "inputs": {
            "Workcenter_Key": Workcenter_Key
        }
    }

    headers = {
            "Content-Type": "application/json"
    }
    
    response = requests.post(
        url,
        auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
        json=payload,               
        headers=headers
    )
    if str(response.status_code)=="200":
    #    print(response.json()["tables"][0]["rows"])
        Part_Key=response.json()["tables"][0]["rows"][0][17]
        Part_Operation_Key=response.json()["tables"][0]["rows"][0][18]
      
        #再查询4658获取standard数量
        url = "https://nswmes.on.plex.com/api/datasources/4658/execute"
        payload = {
            "inputs": {
                "Part_Key": Part_Key,
                "Part_Operation_Key": Part_Operation_Key,
                "Workcenter_Key": Workcenter_Key
            }
        }
        response = requests.post(
            url,
            auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
            json=payload,               
            headers=headers
        )
        if str(response.status_code)=="200":
            return float(response.json()["outputs"]["Standard_Quantity"])
        else:
            return "erro"


# API for record production  to db by manual"""""""""""""""
@app.post("/api/recordmanual")
def upload(data: dict, db: Session = Depends(get_db)):
    if str(data.get("workcenter_id"))=="pressing_shop":
        Workcenter_ID="2d26cb8f-2bc3-4f5c-ad6a-e84a7d414cde"
    elif str(data.get("workcenter_id"))=="welding_shop":
        Workcenter_ID="c05ae26a-025d-4b35-b013-a6d1ab94908c"
    elif str(data.get("workcenter_id"))=="painting_shop":
        Workcenter_ID="224772fc-15ba-4674-92a4-6689211e00ba"
    
    # point to vehicle-seria-02 for now, need to change in the future
    # use the plex API "list parts" to get the part id
    Part_ID="794ae588-fa5e-4566-ad3d-c830269d342e"
                    
    #load source inventory
    if not fetch_plex_source_data(Workcenter_ID,Part_ID,float(data.get("quantity"))):
        return {"msg": 0}
    
    # 1.only to send this record
    # record into DB firstly
    # write data into db
    record = ProductionRecord(
        user_id=data.get("user_id"),
        workcenter_id=data.get("workcenter_id"),
        machine_id=data.get("machine_id"),
        job_id=data.get("job_id"),
        product_code=data.get("product_code"),
        quantity=data.get("quantity"),
        synced=0,
        report_auto=data.get("report_auto"),
        timestamp=datetime.now(),
        created_at=datetime.now()
    )
    try:
        db.add(record)
        db.commit()       
    except Exception as e:
        print("Plex report failed:", e)
        return {"msg": 0}
    
    Workcenter_Key=85277
    if data.get("workcenter_id")== "pressing_shop":
        Workcenter_Key=85277
    elif data.get("workcenter_id") == "welding_shop":
        Workcenter_Key=85278
    elif data.get("workcenter_id") == "painting_shop":
        Workcenter_Key=85279

    # 2.then send the production record
    try:
        lastrecord = db.query(ProductionRecord).filter(ProductionRecord.user_id == data.get("user_id") and ProductionRecord.quantity==data.get("quantity") and ProductionRecord.report_auto == 0).order_by("id").limit(1)

        ## 1.先判断是否要新增container，也就是先判断当前可持续写入储量的container是否存在，而且没有达到标准数量，而且还是非full状态
        # =================还没有找到对应的接口 20351可以获取所有的这个job对应的workcenter的container清单
        url = "https://nswmes.on.plex.com/api/datasources/20351/execute"
        payload = {
            "inputs": {
                "Container_Status": "OK",
                "Job_No": str(data.get("job_id"))
            }
        }

        headers = {
                "Content-Type": "application/json"
        }
        
        response = requests.post(
            url,
            auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
            json=payload,               
            headers=headers
        )

        lastrow=""
        if str(response.status_code)=="200":
            lastrow= max(response.json()["tables"][0]["rows"], key=lambda x: x[1])

        # 2.获取标准数量
        standard_count=int(query_standard_quality(Workcenter_Key,0))
        print("standard_count",standard_count)
        print("int(lastrow[-1])",int(lastrow[-1]))
        add_count= int(data.get("quantity"))

        # 如果最后一个container的数量大于标准container数量，则设置它为full并直接跳过
        if int(lastrow[-1])>=standard_count:
            url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
            payload = {
                "inputs": {
                    "Workcenter_Key": Workcenter_Key,
                    "Container_Full":True,
                    "Serial_No": str(lastrow[1])
                }
            }

            headers = {
                    "Content-Type": "application/json"
            }
            
            response = requests.post(
                url,
                auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
                json=payload,               
                headers=headers
            )
        else:
            #此处假设container的状态没有被设置为full，否则会出错**************************************
            #增加到最后一个container
            url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
            add_count_last=0
            full_flag_last=False
            if add_count >=(standard_count-int(lastrow[-1])):
                add_count_last= standard_count-int(lastrow[-1])
                add_count= add_count - add_count_last
                full_flag_last=True
                payload = {
                    "inputs": {
                        "Workcenter_Key": Workcenter_Key,
                        "Quantity": add_count_last,
                        "Container_Full":full_flag_last,
                        "Start_New_Container": True
                    }
                }
            else:
                add_count_last= add_count
                add_count=-1
                full_flag_last=False
                payload = {
                    "inputs": {
                        "Workcenter_Key": Workcenter_Key,
                        "Quantity": add_count_last,
                        "Container_Full":full_flag_last,
                        "Start_New_Container": False
                    }
                }
            
            response = requests.post(
                url,
                auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
                json=payload,               
                headers=headers
            )

            if not str(response.status_code)=="200":
                return {"msg": 0}
        
        if add_count<0:
            return {"msg": 1}
        
        #以下代码只有当汇报数量较大时才会执行
        # 当前仅仅是整数，后续需要支持双精度
        addflag=False
        while add_count>standard_count:
            add_count=add_count-standard_count

            url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
            payload = {
                "inputs": {
                    "Workcenter_Key": Workcenter_Key,
                    "Quantity": standard_count,
                    "Container_Full":True,
                    "Start_New_Container": True
                }
            }

            headers = {
                    "Content-Type": "application/json"
            }
            
            response = requests.post(
                url,
                auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
                json=payload,               
                headers=headers
            )
            if str(response.status_code)=="200":
                lastrecord.synced = 1
            else:
                addflag=True

        # 如果最后还剩下数量，则作为一个新的container
        if add_count>0:
            url = "https://nswmes.on.plex.com/api/datasources/20446/execute"
            payload = {
                "inputs": {
                    "Workcenter_Key": Workcenter_Key,
                    "Quantity": add_count,
                    "Container_Full":False,
                    "Start_New_Container": False
                }
            }

            headers = {
                    "Content-Type": "application/json"
            }
            
            response = requests.post(
                url,
                auth = HTTPBasicAuth("NSWTrainingPCN3PWs@plex.com", "4b3e197-1b48-4"), 
                json=payload,               
                headers=headers
            )

        #如果数量很大，这里存在如果部分没有更新完成的话，就存在风险**********************要注意！
        #后续的自动增加数量也是
        if  not addflag:
            db.commit()
            return {"msg": 1}
        else:
            return {"msg": 0}
    except Exception as e:
        print("Plex report failed:", e)
        return {"msg": 0}

# API for getting the workcenter info list
@app.get("/api/workinfolist")
def get_workinfo_list(is_sent: Optional[int] = Query(None), db: Session = Depends(get_db)):
    def to_dict(record):
        return { 
            "id": record.id,
            "workcenter_id": record.workcenter_id,
            "job_id": record.job_id,
            "user_id": record.user_id,
            "product_code": record.product_code,
            "quantity": record.quantity,
            "machine_id": record.machine_id,
            "report_auto":bool(record.report_auto),
            "is_sent": bool(record.synced),
            "timestamp": record.timestamp
    }
    query = db.query(ProductionRecord)

    if is_sent is not None:
        query = query.filter(ProductionRecord.synced == is_sent)
    results = query.order_by(ProductionRecord.id.desc()).all()
    data = [to_dict(r) for r in results]

    return data

# API for record logs
@app.get("/api/logs")
def get_logs( page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    query = db.query(SystemLogs)
    total = query.count()
    rows = query.order_by(SystemLogs.id.desc()) \
                .offset((page - 1) * page_size) \
                .limit(page_size) \
                .all()

    data = [
        {
            "id": row.id,
            "type": row.type,
            "message": row.message,
            "created_at": row.created_at
        }
        for row in rows
    ]

    return {
        "data": data,
        "total": total,
        "page": page,
        "page_size": page_size
    }

# API for get workcenter and job info
@app.get("/api/workcenter_jobs")
def get_workcenterinfo(workcenter_key: str):
    db = SessionLocal()
    records=""
    if workcenter_key=="all":
        records=db.query(Workcenter).order_by(Workcenter.id.desc()).limit(30).all()
    else:
        records=db.query(Workcenter).filter(Workcenter.workcenter_name == workcenter_key).order_by(Workcenter.id.desc()).limit(30).all()
        
    categories = []
    values = []

    for r in records:
        categories.append(r.id)
        values.append(r.job_quantity)
        
    db.close()
    returnJason= {
        "categories": categories,
        "series": [
            {
                "name": "production plan",
                "data": values
            }
        ]
    }
    return returnJason

# API for get production records list
@app.get("/api/production_records")
def get_productions( production_key:str): 
    db = SessionLocal()
    records=""
    if production_key=="all":
        records = (
            db.query(ProductionRecord)
            .order_by(ProductionRecord.id.desc())
            .limit(30)
            .all()
        )
    else:
        records = (
            db.query(ProductionRecord)
            .filter(ProductionRecord.product_code == production_key)
            .order_by(ProductionRecord.id.desc())
            .limit(30)
            .all()
        )
        
    categories = []
    values = []

    for r in records:
        categories.append(int(r.timestamp.timestamp() * 1000))
        values.append(r.quantity)
        
    db.close()
    returnJason= {
        "categories": categories,
        "series": [
            {
                "name": "production actual",
                "data": values
            }
        ]
    }
    return returnJason

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0",reload=True)